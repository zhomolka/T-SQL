-- DEMO 1
-- SQL OS schedulers
SELECT 
  scheduler_id
  , cpu_id
  , status
  , current_tasks_count
  , runnable_tasks_count
  , current_workers_count
  , active_workers_count
  , load_factor
  , quantum_length_us
FROM sys.dm_os_schedulers
WHERE
	scheduler_id < 255;

-- workers
SELECT
  worker_address
  , scheduler_address
  , is_preemptive
  , pending_io_byte_count
  , state
  , last_wait_type
  , tasks_processed_count
FROM sys.dm_os_workers;

-- tasks
SELECT
  scheduler_id
  , task_state
  , session_id
  , request_id
FROM sys.dm_os_tasks
WHERE
	session_id > 50;



-- Demo 2
-- waits - dm views
SELECT *
FROM sys.dm_os_waiting_tasks
WHERE
	session_id > 50;

SELECT
	blocking.session_id
	, blocked.session_id
	, waitstats.wait_type
	, waitstats.wait_duration_ms
	, waitstats.resource_description
	, blocked_text = blocked_cache.text
	, blocking_text = blocking_cache.text
FROM
	sys.dm_exec_connections AS blocking
	INNER JOIN sys.dm_exec_requests blocked
		ON blocking.session_id = blocked.blocking_session_id
	CROSS APPLY sys.dm_exec_sql_text(blocked.sql_handle) blocked_cache
	CROSS APPLY sys.dm_exec_sql_text(blocking.most_recent_sql_handle) blocking_cache
	INNER JOIN sys.dm_os_waiting_tasks waitstats
		ON waitstats.session_id = blocked.session_id


SELECT *
FROM sys.dm_os_wait_stats

