USE [FS_custom]
GO

/****** Object:  UserDefinedFunction [dbo].[Tile_DuplexProbe]    Script Date: 24.04.2020 9:41:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		<Václav Kubát>
-- Create date: <20.4.2020>
-- Description:	<Knotrola stavu Duplexu>
-- =============================================
CREATE FUNCTION [dbo].[Tile_DuplexProbe] 
(
@Now as datetime
)
RETURNS 
@Tile TABLE 
(
	Rank int
	,Text nvarchar (30)
	,Number nvarchar (20)
	,BackgroundImage nvarchar (50)
	,BackColor nvarchar (10)
	,FrontColor nvarchar (10)
	,Glyph nvarchar (30)
	,Url nvarchar (200)

)
AS
BEGIN

--info viz:
--select *from icc.dbo.WorkflowEvent order by TimeUtc desc
--declare @ProbeText_M as nvarchar (500) = (select ResultText from iCC.dbo.ScenarioResultValue where ScenarioResultId = '551D4F52-3B83-EA11-A89A-00155D12CC07')

--declare @now as datetime = getdate ()

--Zjistim posledni stav M/S
declare @ProbeText_M as nvarchar (500) = (select top 1 b.ResultText--,b.TargetColumn,a.ResultTime,a.TargetColumn
											from iCC.dbo.ScenarioResultValue as a with (nolock)
											inner join iCC.dbo.ScenarioResultValue as b with (nolock) on a.ScenarioResultId = b.ScenarioResultId and b.TargetColumn = 'DuplexInfo_M'
											where a.TargetColumn = 'DuplexInfoTime' and a.ResultTime > dateadd(minute,-3,@Now)
											order by a.ResultTime desc)

declare @ProbeText_S as nvarchar (500) = (select top 1 b.ResultText--,b.TargetColumn,a.ResultTime,a.TargetColumn
											from iCC.dbo.ScenarioResultValue as a with (nolock)
											inner join iCC.dbo.ScenarioResultValue as b with (nolock) on a.ScenarioResultId = b.ScenarioResultId and b.TargetColumn = 'DuplexInfo_S'
											where a.TargetColumn = 'DuplexInfoTime' and a.ResultTime > dateadd(minute,-3,@Now)
											order by a.ResultTime desc)

--pokud nejsou aktualni informace (chyba vraceni Probe informaci aspod...) info obratit se na admina/atlantis
	if (@ProbeText_M is null and @ProbeText_S is null)
	begin
		insert into @Tile 
				SELECT 1 as rank
					,'Contact your ADMIN' as Text
					,'NO info' AS Number
					,'' as BackgroundImage
					,'#990000'
						 as BackColor
					,'#ffffff'
						 as FrontColor
					,'fa fa-question-circle-o'
						as Glyph
					,''
						as Url
	return
	end

--usporadani info Master
	set @ProbeText_M = REPLACE(REPLACE(REPLACE(REPLACE(SUBSTRING (@ProbeText_M,CHARINDEX('<p>',@ProbeText_M),LEN(@ProbeText_M)),'</body>',''),'<p>',''),'</p>',''),',','')

	declare @ProbeInfo_M as table ([Value] nvarchar (30))
	insert into @ProbeInfo_M
	SELECT Value FROM STRING_SPLIT(@ProbeText_M , ' ') where value <> '' and value like '%=%'

	declare @Status_M as bit
	declare @Duplex_M as bit
	declare @Running_M as bit
	declare @DB_M as bit
	declare @PBX_M as bit

	select
		@Status_M = max(case when Value like 'STATUS=OK%' then 1 when Value like 'STATUS=%' then 0 end)
		,@Duplex_M = max(case when Value like 'DUPLEX=OK%' then 1 when Value like 'DUPLEX=%' then 0 end)
		,@Running_M = max(case when Value like 'RUNNING=OK%' then 1 when Value like 'RUNNING=%' then 0 end)
		,@DB_M = max(case when Value like 'DB=OK%' then 1 when Value like 'DB=%' then 0 end)
		,@PBX_M = max(case when Value like 'PBX=OK%' then 1 when Value like 'PBX=%' then 0 end)
	from @ProbeInfo_M

--pokud je Master OK, neni potreba info ze Slave
if (@Status_M = 1) GoTo DuplexTile
--usporadani info Slave
	set @ProbeText_S = REPLACE(REPLACE(REPLACE(REPLACE(SUBSTRING (@ProbeText_S,CHARINDEX('<p>',@ProbeText_S),LEN(@ProbeText_S)),'</body>',''),'<p>',''),'</p>',''),',','')

	declare @ProbeInfo_S as table ([Value] nvarchar (30))
	insert into @ProbeInfo_S
	SELECT Value FROM STRING_SPLIT(@ProbeText_S , ' ') where value <> '' and value like '%=%'

	declare @Status_S as bit
	declare @Duplex_S as bit
	declare @Running_S as bit
	declare @DB_S as bit
	declare @PBX_S as bit

	select
		@Status_S = max(case when Value like 'STATUS=OK%' then 1 when Value like 'STATUS=%' then 0 end)
		,@Duplex_S = max(case when Value like 'DUPLEX=OK%' then 1 when Value like 'DUPLEX=%' then 0 end)
		,@Running_S = max(case when Value like 'RUNNING=OK%' then 1 when Value like 'RUNNING=%' then 0 end)
		,@DB_S = max(case when Value like 'DB=OK%' then 1 when Value like 'DB=%' then 0 end)
		,@PBX_S = max(case when Value like 'PBX=OK%' then 1 when Value like 'PBX=%' then 0 end)
	from @ProbeInfo_S

	--	select @Status_M
	--,@Duplex_M
	--,@Running_M
	--,@DB_M
	--,@PBX_M

	--select @Status_S
	--,@Duplex_S
	--,@Running_S
	--,@DB_S
	--,@PBX_S


DuplexTile:

--insert do dlazdice
insert into @Tile 
			SELECT 1 as rank
				,case 
					when @Status_M = 1 then 'Duplex Info' 
					when (isnull(@Status_M,0) = 0 and @Status_S = 1) then 'go to Slave' 
					else 'please contact your ADMIN' 
					end 
						as Text
				,case 
					when @Status_M = 1 then 'OK' 
					when (isnull(@Status_M,0) = 0 and @Status_S = 1) then 'Click HERE' 
					else '-' 
					end 
						AS Number
				,''
					as BackgroundImage
				,case 
					when @Status_M = 1 then '#b3ffb3'
					when (isnull(@Status_M,0) = 0 and @Status_S = 1) then '#ff3300' 
					else '#424ef5' 
					end
						as BackColor
				,case 
					when @Status_M = 1 then '#000000'
					when (isnull(@Status_M,0) = 0 and @Status_S = 1) then '#ffffff' 
					else '#ffffff'
					end 
						as FrontColor
				,case 
					when @Status_M = 1 then 'fa fa-check-circle-o'
					when (isnull(@Status_M,0) = 0 and @Status_S = 1) then 'fa fa-hand-o-right' 
					else 'fa fa-chain-broken'
					end 
						as Glyph
				,case
					when @Status_M = 1 then 'http://192.168.18.101/ReactClient/pages/portal.html#Super_Domu' --URL na Master
					when (isnull(@Status_M,0) = 0 and @Status_S = 1) then 'http://192.168.18.102/ReactClient/pages/portal.html#Super_Domu' --URL na Slave
					else '-'
					end
						as Url
RETURN 
END



GO

