/* Port_Nove: Dlazdice nové interakce + DuplexProbe */
INSERT [DataQuery] ([DataQueryId], [DisplayName], [Description], [QueryGroup], [QuerySortExpression], [QueryText], [ManualFilter], [SnapshotInterval], [CacheInterval], [TimeLine], [Deleted], [LogLevel])
 VALUES(N'eb7ce458-05da-42ec-a31a-3485454ccd46',N'Dlazdice nové interakce + DuplexProbe',NULL,N'Port_Nove',N'Rank',N'
/*Dupex Probe*/
SELECT 0 as [Rank], [Text], Number, BackgroundImage, BackColor, FrontColor, Glyph, [Url] FROM [FS_custom].[dbo].[Tile_DuplexProbe_Small] (@Now)

Union all
/*Outbound-New.png*/
SELECT 1 as [Rank]
	,''Call'' as Text
	,'''' as Number
	,'''' as BackgroundImage
	,''#333333'' as BackColor
	,''#ffffff'' as FrontColor
	,''fa fa-phone'' as Glyph
	,''OutCallEditor.html?Predist=true'' as Url

Union all
/*Email-New.png*/
SELECT 2 as [Rank]
	,''Mail'' as Text
	,'''' as Number
	,'''' as BackgroundImage
	,''#333333'' as BackColor
	,''#ffffff'' as FrontColor
	,''fa fa-envelope-o'' as Glyph
	,''MessageEditor.html?Plus=true&MsgType=Email'' as Url
		
Union all
/*Issue-New.png*/
SELECT 3 as [Rank]
	,''Issue'' as Text
	,'''' as Number
	,'''' as BackgroundImage
	,''#333333'' as BackColor
	,''#ffffff'' as FrontColor
	,''fa fa-folder-open-o'' as Glyph
	,''IssueEditor.html?'' as Url
/*		
Union all
/*SMS-New.png*/
SELECT 4 as [Rank]
	,''SMS'' as Text
	,'''' as Number
	,'''' as BackgroundImage
	,''#333333'' as BackColor
	,''#ffffff'' as FrontColor
	,''fa fa-mobile'' as Glyph
	,''MessageEditor.html?Plus=true&MsgType=SMS'' as Url
		
Union all
/*Note-New.png*/
SELECT 5 as [Rank]
	,''Note'' as Text
	,'''' as Number
	,'''' as BackgroundImage
	,''#333333'' as BackColor
	,''#ffffff'' as FrontColor
	,''fa fa-sticky-note-o'' as Glyph
	,''MessageEditor.html?Plus=true&MsgType=Note'' as Url
		
Union all
/*Task-New.pn*/
SELECT 6 as [Rank]
	,''Task'' as Text
	,'''' as Number
	,'''' as BackgroundImage
	,''#333333'' as BackColor
	,''#ffffff'' as FrontColor
	,''fa fa-calendar-o'' as Glyph
	,''MessageEditor.html?Plus=true&MsgType=Task'' as Url
*/',0,NULL,NULL,NULL,0,0)
INSERT [DataQueryColumn] ([DataQueryColumnId], [DataQueryId], [DisplayName], [Model], [TargetColumn], [TargetFormat], [UrlColumn], [UrlFormat], [GuidColumn], [Convertor], [SortExpression], [SortExpressionDesc], [NoFilter], [Width], [Rank], [Color], [Deleted], [SqlCmd], [Css], [ToolTip], [LiteralGroup], [GlyphColumn], [GlyphFormat], [GdprSensitivity])
 VALUES (N'3938a572-f12d-4d83-a569-d2528d46b3fc',N'eb7ce458-05da-42ec-a31a-3485454ccd46',N'Rank',N'Integer',N'Rank',NULL,NULL,NULL,NULL,NULL,N'Rank',NULL,0,60,10,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL, NULL)
INSERT [DataQueryColumn] ([DataQueryColumnId], [DataQueryId], [DisplayName], [Model], [TargetColumn], [TargetFormat], [UrlColumn], [UrlFormat], [GuidColumn], [Convertor], [SortExpression], [SortExpressionDesc], [NoFilter], [Width], [Rank], [Color], [Deleted], [SqlCmd], [Css], [ToolTip], [LiteralGroup], [GlyphColumn], [GlyphFormat], [GdprSensitivity])
 VALUES (N'6b52e0d2-5949-4a20-998a-690cca1cb724',N'eb7ce458-05da-42ec-a31a-3485454ccd46',N'Text',N'Text',N'Text',NULL,NULL,NULL,NULL,NULL,N'Text',NULL,0,80,20,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL, NULL)
INSERT [DataQueryColumn] ([DataQueryColumnId], [DataQueryId], [DisplayName], [Model], [TargetColumn], [TargetFormat], [UrlColumn], [UrlFormat], [GuidColumn], [Convertor], [SortExpression], [SortExpressionDesc], [NoFilter], [Width], [Rank], [Color], [Deleted], [SqlCmd], [Css], [ToolTip], [LiteralGroup], [GlyphColumn], [GlyphFormat], [GdprSensitivity])
 VALUES (N'4a41c318-4772-4a0f-8171-a37d283c9bd8',N'eb7ce458-05da-42ec-a31a-3485454ccd46',N'Number',N'Text',N'Number',NULL,NULL,NULL,NULL,NULL,N'Number',NULL,0,60,30,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL, NULL)
INSERT [DataQueryColumn] ([DataQueryColumnId], [DataQueryId], [DisplayName], [Model], [TargetColumn], [TargetFormat], [UrlColumn], [UrlFormat], [GuidColumn], [Convertor], [SortExpression], [SortExpressionDesc], [NoFilter], [Width], [Rank], [Color], [Deleted], [SqlCmd], [Css], [ToolTip], [LiteralGroup], [GlyphColumn], [GlyphFormat], [GdprSensitivity])
 VALUES (N'b6ce8165-2bfc-4141-a682-e19dfb9e3086',N'eb7ce458-05da-42ec-a31a-3485454ccd46',N'BackColor',N'Text',N'BackColor',NULL,NULL,NULL,NULL,NULL,N'BackColor',NULL,0,80,40,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL, NULL)
INSERT [DataQueryColumn] ([DataQueryColumnId], [DataQueryId], [DisplayName], [Model], [TargetColumn], [TargetFormat], [UrlColumn], [UrlFormat], [GuidColumn], [Convertor], [SortExpression], [SortExpressionDesc], [NoFilter], [Width], [Rank], [Color], [Deleted], [SqlCmd], [Css], [ToolTip], [LiteralGroup], [GlyphColumn], [GlyphFormat], [GdprSensitivity])
 VALUES (N'2f14d928-75f3-45d8-ab44-a63635c8aff0',N'eb7ce458-05da-42ec-a31a-3485454ccd46',N'FrontColor',N'Text',N'FrontColor',NULL,NULL,NULL,NULL,NULL,N'FrontColor',NULL,0,80,50,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL, NULL)
INSERT [DataQueryColumn] ([DataQueryColumnId], [DataQueryId], [DisplayName], [Model], [TargetColumn], [TargetFormat], [UrlColumn], [UrlFormat], [GuidColumn], [Convertor], [SortExpression], [SortExpressionDesc], [NoFilter], [Width], [Rank], [Color], [Deleted], [SqlCmd], [Css], [ToolTip], [LiteralGroup], [GlyphColumn], [GlyphFormat], [GdprSensitivity])
 VALUES (N'7536b97d-625a-4c2b-9962-bef3b32fe1df',N'eb7ce458-05da-42ec-a31a-3485454ccd46',N'Glyph',N'Text',N'Glyph',NULL,NULL,NULL,NULL,NULL,N'Glyph',NULL,0,80,60,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL, NULL)
INSERT [DataQueryColumn] ([DataQueryColumnId], [DataQueryId], [DisplayName], [Model], [TargetColumn], [TargetFormat], [UrlColumn], [UrlFormat], [GuidColumn], [Convertor], [SortExpression], [SortExpressionDesc], [NoFilter], [Width], [Rank], [Color], [Deleted], [SqlCmd], [Css], [ToolTip], [LiteralGroup], [GlyphColumn], [GlyphFormat], [GdprSensitivity])
 VALUES (N'aff18a86-8a04-42c6-8f13-4c70679e3eca',N'eb7ce458-05da-42ec-a31a-3485454ccd46',N'Url',N'Text',N'Url',NULL,N'Url',N'http://FrontStage/ReactClient/Pages/{0}',NULL,NULL,N'Url',NULL,0,80,70,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL, NULL)
INSERT [DataQueryColumn] ([DataQueryColumnId], [DataQueryId], [DisplayName], [Model], [TargetColumn], [TargetFormat], [UrlColumn], [UrlFormat], [GuidColumn], [Convertor], [SortExpression], [SortExpressionDesc], [NoFilter], [Width], [Rank], [Color], [Deleted], [SqlCmd], [Css], [ToolTip], [LiteralGroup], [GlyphColumn], [GlyphFormat], [GdprSensitivity])
 VALUES (N'9b3a9d75-dc47-42b7-b0ba-4b4896f8271d',N'eb7ce458-05da-42ec-a31a-3485454ccd46',N'BackgroundImage',N'Text',N'BackgroundImage',NULL,NULL,NULL,NULL,NULL,N'BackgroundImage',NULL,0,300,80,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL, NULL)

