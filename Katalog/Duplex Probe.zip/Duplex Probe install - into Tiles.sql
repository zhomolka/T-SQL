/*Duplex Probe install - into Tiles*/

USE [iCC]
GO

--Formular:
	INSERT INTO [dbo].[Scenario]
			   ([ScenarioId],[DisplayName],[Description],[GroupName],[OnSaveSqlCmd],[OnCreateSqlCmd],[Deleted],[GdprInheritInboundCall],[GdprInheritOutboundCall],[GdprInheritMessage],[GdprInheritChat],[GdprInheritIssue],[GdprInheritContact],[LogLevel])
		 VALUES
			   ('1F8108C3-4109-4B4E-9C63-1B6505FC8B43','Duplex','Probe','System',NULL,NULL,	0,	0,	0,	0,	0,	0,	0,	0)
	GO

	INSERT INTO [dbo].[Screen]
			   ([ScreenId],[ScenarioId],[DisplayName],[Description],[Rank],[FinishButton],[SaveButton],[ConditionScreenControlId],[ConditionText],[Feature],[Deleted])
		 VALUES
			   ('4311394A-3F04-4BFF-A93B-86B52CA2C4BA','1F8108C3-4109-4B4E-9C63-1B6505FC8B43','Info','',100,0,0,NULL,'',NULL,0)
	GO

	INSERT INTO [dbo].[ScreenControl]
			   ([ScreenControlId],[ScreenId],[DisplayName],[Description],[TargetColumn],[Rank],[ControlType],[ControlNumber],[ControlText],[ReadOnly],[MandatoryField],[ShowInList],[Deleted],[GdprSensitivity],[ExportField])
		 VALUES
			   ('0CA1D37A-9020-4B74-BF8C-7AAD9E21C5C7',	'4311394A-3F04-4BFF-A93B-86B52CA2C4BA',	'DuplexInfo Slave','DuplexInfo Slave','DuplexInfo_S',200,'TextArea',1,'',0,	0,	0,	0,	0,	0)
	GO
	INSERT INTO [dbo].[ScreenControl]
			   ([ScreenControlId],[ScreenId],[DisplayName],[Description],[TargetColumn],[Rank],[ControlType],[ControlNumber],[ControlText],[ReadOnly],[MandatoryField],[ShowInList],[Deleted],[GdprSensitivity],[ExportField])
		 VALUES
			   ('F2BCA3C9-BB52-4876-9ADA-84BC8E9C6F36',	'4311394A-3F04-4BFF-A93B-86B52CA2C4BA',	'Set time','zapsani casu behu WF','DuplexInfoTime',50,'DateTime',NULL,NULL,0,	0,	0,	0,	0,	0)
	GO
	INSERT INTO [dbo].[ScreenControl]
			   ([ScreenControlId],[ScreenId],[DisplayName],[Description],[TargetColumn],[Rank],[ControlType],[ControlNumber],[ControlText],[ReadOnly],[MandatoryField],[ShowInList],[Deleted],[GdprSensitivity],[ExportField])
		 VALUES
			   ('CC97FD87-E9A4-4685-B66E-D99EB5DD8D53',	'4311394A-3F04-4BFF-A93B-86B52CA2C4BA',	'DuplexInfo Master','DuplexInfo Master','DuplexInfo_M',100,'TextArea',1,'',0,	0,	0,	0,	0,	0)
	GO

--WorkFlow:
	INSERT INTO [dbo].[Workflow]
			   ([WorkflowId],[DisplayName],[Description],[GroupName],[TimeOut],[ScenarioId],[Deleted])
		 VALUES
			   ('EBB55734-BD83-EA11-A89A-00155D12CC07','Duplex info M/S save',NULL,'System',30,'1F8108C3-4109-4B4E-9C63-1B6505FC8B43',0)
	GO
	INSERT INTO [dbo].[Workflow]
			   ([WorkflowId],[DisplayName],[Description],[GroupName],[TimeOut],[ScenarioId],[Deleted])
		 VALUES
			   ('06D8873C-F685-EA11-A89A-00155D12CC07','Duplex info M/S delete',NULL,'System',300,'1F8108C3-4109-4B4E-9C63-1B6505FC8B43',0)
	GO

	INSERT INTO [dbo].[WorkflowStep]
			   ([WorkflowStepId],[WorkflowId],[DisplayName],[Rank],[Action],[Parameters],[Targets],[TargetId],[ReferenceId],[Reference],[ReferenceText],[TimeOut],[TimeMode],[TimeFrom],[TimeTo],[InstanceCondition],[TargetOnTimeOut],[TargetOnSuccess],[TargetOnFailure],[Deleted])
		 VALUES
			   ('FA610344-BD83-EA11-A89A-00155D12CC07',	'EBB55734-BD83-EA11-A89A-00155D12CC07',	'Info Master save',200,	'QueryUrlText',	'##None##',	'DuplexInfo_M;SSPI',	NULL,	NULL,65001,	'http://cc-be-app-1/ReactClient/Probes/Default.html',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0)
	GO
	INSERT INTO [dbo].[WorkflowStep]
			   ([WorkflowStepId],[WorkflowId],[DisplayName],[Rank],[Action],[Parameters],[Targets],[TargetId],[ReferenceId],[Reference],[ReferenceText],[TimeOut],[TimeMode],[TimeFrom],[TimeTo],[InstanceCondition],[TargetOnTimeOut],[TargetOnSuccess],[TargetOnFailure],[Deleted])
		 VALUES
			   ('71044F54-BD83-EA11-A89A-00155D12CC07',	'EBB55734-BD83-EA11-A89A-00155D12CC07',	'Info Slave save',300,	'QueryUrlText',	'##None##',	'DuplexInfo_S;SSPI',	NULL,	NULL,65001,	'http://cc-be-app-2.corp.tipsport.cz/ReactClient/Probes/Default.html',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0)
	GO
	INSERT INTO [dbo].[WorkflowStep]
			   ([WorkflowStepId],[WorkflowId],[DisplayName],[Rank],[Action],[Parameters],[Targets],[TargetId],[ReferenceId],[Reference],[ReferenceText],[TimeOut],[TimeMode],[TimeFrom],[TimeTo],[InstanceCondition],[TargetOnTimeOut],[TargetOnSuccess],[TargetOnFailure],[Deleted])
		 VALUES
			   ('82A3A8D7-0884-EA11-A89A-00155D12CC07',	'EBB55734-BD83-EA11-A89A-00155D12CC07',	'DuplexInfoTime',100,	'SetTarget',	'##CurrentTime##',	'DuplexInfoTime',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0)
	GO
	INSERT INTO [dbo].[WorkflowStep]
			   ([WorkflowStepId],[WorkflowId],[DisplayName],[Rank],[Action],[Parameters],[Targets],[TargetId],[ReferenceId],[Reference],[ReferenceText],[TimeOut],[TimeMode],[TimeFrom],[TimeTo],[InstanceCondition],[TargetOnTimeOut],[TargetOnSuccess],[TargetOnFailure],[Deleted])
		 VALUES
			   ('08D8873C-F685-EA11-A89A-00155D12CC07',	'06D8873C-F685-EA11-A89A-00155D12CC07',	'Info delete',200,	'QueryDb',	'##None##',	'EXECUTE [FS_custom].[dbo].[DuplexProbe_DeleteOld] 1',	NULL,	NULL,	NULL,	'Provider=SQLNCLI11;Server=cc-be-cdbl-icc;Database=iCC; Trusted_Connection=yes;',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0)
	GO

--ActionTrigger
	INSERT INTO [dbo].[ActionTrigger]
			   ([ActionTriggerId],[DisplayName],[Description],[GroupName],[CommandText],[WorkflowId],[WorkflowXaml],[Model],[Interval],[TimeMode],[TimeFrom],[TimeTo],[ReferenceKey],[LastRunUtc],[LastWorkflowInstanceId],[Suspended],[Deleted],[Offset],[LaunchTime])
		 VALUES
			   ('710EFEDE-A681-4C57-8762-11D99F2E440C','Duplex Info - save','Sonda pro vraceni stavu Duplexu','System',NULL,'EBB55734-BD83-EA11-A89A-00155D12CC07',NULL,'Interval',1,NULL,NULL,NULL,NULL,'2020-04-24 07:22:13.187',NULL,0,0,NULL,NULL)
	GO


	INSERT INTO [dbo].[ActionTrigger]
			   ([ActionTriggerId],[DisplayName],[Description],[GroupName],[CommandText],[WorkflowId],[WorkflowXaml],[Model],[Interval],[TimeMode],[TimeFrom],[TimeTo],[ReferenceKey],[LastRunUtc],[LastWorkflowInstanceId],[Suspended],[Deleted],[Offset],[LaunchTime])
		 VALUES
			   ('014F7A77-BE0F-47B1-88A2-A090D9FD6243','Duplex Info - delete','Mazani stareho infa o stavu Duplexu','System',NULL,'06D8873C-F685-EA11-A89A-00155D12CC07',NULL,'Schedule',NULL,'DayInWeek','2020-04-20 23:30:00.000','2020-04-26 23:55:59.900',NULL,'2020-04-24 21:30:00.000',NULL,0,0,NULL,'2020-04-24 23:31:00.000')
	GO

