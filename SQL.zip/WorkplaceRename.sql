BEGIN TRANSACTION

UPDATE Workplace SET DisplayName = 'Lisecov� Krist�na' WHERE Number='20257' AND Deleted=0 
UPDATE Workplace SET DisplayName = 'Vyletov� Jana' WHERE Number='20258' AND Deleted=0
UPDATE Workplace SET DisplayName = 'Slav�kov� Barbora' WHERE Number='20262' AND Deleted=0 
UPDATE Workplace SET DisplayName = 'Zbo�il Jan' WHERE Number='20251' AND Deleted=0 
UPDATE Workplace SET DisplayName = 'Kepkov� Monika' WHERE Number='20264' AND Deleted=0 
UPDATE Workplace SET DisplayName = 'Voln� pracovi�t�' WHERE Number='20265' AND Deleted=0
UPDATE Workplace SET DisplayName = 'Voln� pracovi�t�' WHERE Number='20242' AND Deleted=0 
COMMIT TRANSACTION
--ROLLBACK TRANSACTION
