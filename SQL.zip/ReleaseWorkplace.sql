USE [iCC]
GO
DECLARE @Workplace AS VARCHAR(24)
SET @Workplace = '9680'
-- Na�ten� od obsluhy
--accept l_dept number format '99' prompt 'Department #: '

SELECT 'Prov�d�m n�pravu pracovi�t� '+@Workplace+' - �ek�m 30sekund.' AS Zpr�va
--PRINT 'Prov�d�m n�pravu pracovi�t� '+@Workplace+' - �ek�m 30sekund.'
WAITFOR DELAY '00:00:01'
RAISERROR('',10,1) WITH NOWAIT

BEGIN Transaction
UPDATE [dbo].[Workplace] SET Deleted=1 WHERE Number = @Workplace
COMMIT TRANSACTION

WAITFOR DELAY '00:00:30'

BEGIN Transaction
UPDATE [dbo].[Workplace] SET Deleted=0 WHERE Number = @Workplace
COMMIT TRANSACTION
SELECT 'Konec operace' AS Zpr�va

GO


