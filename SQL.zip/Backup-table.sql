-- Z�lohuje ��sti tabulek a potom je p��padn� ma�e 
DECLARE @from AS datetime=convert(datetime, '2017.01.05')
DECLARE @to AS datetime=convert(datetime, '2017.01.06')
DECLARE @cfrom AS NVARCHAR(100)='convert(datetime, '''+CONVERT ( nvarchar(10), @from , 102 )+''')'
DECLARE @cto AS NVARCHAR(100)='convert(datetime, '''+CONVERT ( nvarchar(10), @To , 102 )+''')'

DECLARE @MyTable AS NVARCHAR(40)='Message'
DECLARE @Command AS NVARCHAR(300)
DECLARE @Condition AS NVARCHAR(300)=' WHERE SubjectField LIKE '+'''Test Atlantis%'''+'AND TimeUtC> '+@cfrom+' AND TimeUtC< '+@cto

--SELECT @Condition
--AND TimeUtc BETWEEN @from AND @to - toto je pomal�
--SELECT 'select * into Icc_Backup.dbo.'+@MyTable+' from iCC.dbo.'+@MyTable+@Condition
/*
*/
EXEC('select * into Icc_Backup.dbo.'+@MyTable+' from iCC.dbo.'+@MyTable+@Condition)
-- Pro maily:
IF @MyTable='Message'
  BEGIN
    EXEC('select * into Icc_Backup.dbo.Attachment from iCC.dbo.Attachment WHERE MessageId IN (SELECT MessageId from Icc.dbo.Message'+@Condition+')')
    EXEC('select * into Icc_Backup.dbo.MessageEvent from iCC.dbo.MessageEvent WHERE MessageId IN (SELECT MessageId from Icc.dbo.Message'+@Condition+')')
  END

--SELECT 'select * into Icc_Backup.dbo.Attachment from iCC.dbo.Attachment WHERE MessageId IN (SELECT MessageId from Icc.dbo.Message'+@Condition+')'


BEGIN TRANSACTION
IF @MyTable='Message'
  BEGIN
    EXEC('DELETE FROM iCC.dbo.Attachment WHERE MessageId IN (SELECT MessageId from Icc.dbo.Message'+@Condition+')')
    EXEC('DELETE FROM iCC.dbo.MessageEvent WHERE MessageId IN (SELECT MessageId from Icc.dbo.Message'+@Condition+')')
  END
EXEC('DELETE FROM iCC.dbo.'+@MyTable+@Condition)

COMMIT TRANSACTION
--ROLLBACK TRANSACTION
/*
*/




