DECLARE @from AS datetime=convert(datetime, '2015.11.01')
DECLARE @to AS datetime=convert(datetime, '2015.11.01')
/*
SET @from=GETDATE()-10
SET @to=GETDATE()
*/
--SELECT * FROM GPRS_Uct(@From, @To,1440)
SELECT * FROM GPRS_Uct_SUM(@From, @To)