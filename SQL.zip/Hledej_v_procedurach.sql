-- Mus� b�t navolena spr�vn� datab�ze
SELECT DISTINCT
  --Name,
       o.name AS Object_Name,
       o.type_desc
	   ,definition
  FROM sys.sql_modules m
       INNER JOIN
       sys.objects o
         ON m.object_id = o.object_id
 WHERE m.definition Like '%GetTargetColumnText%';