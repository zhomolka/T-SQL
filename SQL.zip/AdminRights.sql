-- zapisuje Opr�vn�n� pro pr�ci s Administr�torskou aplikac�
USE [iCC]
GO

INSERT INTO [dbo].[Scope]
           ([ScopeId]
           ,[DisplayName]
           ,[ReferenceData])
     VALUES
           (N'74C70434-E113-4A4C-99A6-8683CA9B5366'
           ,'V�echny z�lo�ky administr�torsk�'
           ,'%AdminPage%')
GO
INSERT INTO [dbo].[Permission]
           ([PermissionId]
           ,[RoleId]
           ,[Degree]
           ,[ScopeId]
           ,[TeamMask])
     VALUES
           (N'D71437BF-EF4E-44DF-B791-4D4E4FBEC53C'
           ,N'17A91897-FB7F-4C18-8542-12888F09E414'
           ,2
           ,N'74C70434-E113-4A4C-99A6-8683CA9B5366'
           ,'ADMIN')

GO


